# MT Wapens
![Spiget Version](https://img.shields.io/spiget/version/76350?color=red&label=version)
![License](https://img.shields.io/github/license/MT-Wapens/MT-Wapens)
![Spiget Downloads](https://img.shields.io/spiget/downloads/76350)
[![Build Status](https://jenkins.jazzkuh.com/job/MTWapens/badge/icon)](https://jenkins.jazzkuh.com/job/MTWapens/)
![Lines](https://img.shields.io/tokei/lines/github/MT-Wapens/MT-Wapens)

![image](https://user-images.githubusercontent.com/32953684/129263279-5ab8ebb4-5137-4473-a383-62068cb9e21d.png)

Met deze plugin is het mogelijk om wapens toe te voegen aan jouw Minetopia server. Hiervoor heb je de Minetopia Texturepack nodig om de juiste textures te zien.

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

## Links
[Discord](https://discord.gg/AvRpCUZ) [Spigot](https://www.spigotmc.org/resources/minetopia-wapens.76350/) [Javadocs](https://api.mtwapens.nl/) [Docs](https://docs.mtwapens.nl)

![Discord](https://discord.com/api/guilds/697454470249971833/widget.png?style=banner3)

## License
[GNU LGPLv2.1](https://choosealicense.com/licenses/lgpl-2.1/) © [Jazzkuh](https://github.com/Jazzkuh/)
