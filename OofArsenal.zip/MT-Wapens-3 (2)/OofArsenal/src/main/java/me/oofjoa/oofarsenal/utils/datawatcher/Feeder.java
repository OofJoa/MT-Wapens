package me.oofjoa.oofarsenal.utils.datawatcher;

/**
* @author Mindgamesnl
*/

public interface Feeder<T> {

    T feed();

}
